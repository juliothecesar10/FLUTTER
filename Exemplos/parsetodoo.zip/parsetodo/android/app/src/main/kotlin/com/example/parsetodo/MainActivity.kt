package com.example.parsetodo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
