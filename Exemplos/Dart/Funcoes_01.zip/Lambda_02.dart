void main() {
  int sumOf(int a, int b) => a + b;

  print(sumOf(2,3));

}
