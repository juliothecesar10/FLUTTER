void main() {
  String nome = funcao();
  print(nome);
}

String funcao() => 'Júlio';

//String funcao{
//  return 'Júlio';
//};
