// Posicional obrigatorio

void main(){
  teste('Julio');
}

void teste(String a) 
{ 
  print('$a ');
}

