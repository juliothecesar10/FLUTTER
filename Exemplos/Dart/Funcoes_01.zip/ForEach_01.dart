void main() {
  var list = [1, 2, 3];
  list.forEach((element) {
    print(element);
  });
}
