// Posicional opcional
void main(){
  teste('Julio',null);
}

void teste(String a, String? b) 
{ 
  print('$a $b');
}
