void main(){
   saudacoes();
   saudacoes();
   saudacoes();
   saudacoes();
}

void saudacoes(){
	print(" Saudações do DART Vader");
	print(" May the force be with you");
}