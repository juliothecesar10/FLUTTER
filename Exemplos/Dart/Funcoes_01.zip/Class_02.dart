main() {

  var employee = Employee();

  var employee1 = Employee();


  Employee employee2 = Employee();

  Employee employee3 = Employee();

  print(employee);
  print(employee.runtimeType);
}

class Employee {
  String name = "john";
}